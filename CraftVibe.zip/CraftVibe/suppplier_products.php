<?php
// supplier_products.php
require_once 'auth_check.php';
require_role('supplier');

$con = mysqli_connect("localhost", "root", "", "tribal_arts_db") or die("Couldn't connect");

// Get supplier information
$user_id = $_SESSION['user_id'];
$supplier_query = mysqli_query($con, "SELECT * FROM suppliers WHERE user_id = $user_id");
$supplier = mysqli_fetch_assoc($supplier_query);

// Handle product actions
if (isset($_GET['action'])) {
    $product_id = intval($_GET['id']);
    
    switch ($_GET['action']) {
        case 'delete':
            $query = "DELETE FROM products WHERE id = $product_id AND supplier_id = {$supplier['id']}";
            if (mysqli_query($con, $query)) {
                log_activity('delete_product', "Deleted product ID: $product_id");
                $success = "Product deleted successfully.";
            } else {
                $error = "Error deleting product: " . mysqli_error($con);
            }
            break;
            
        case 'toggle_status':
            $current_status = mysqli_fetch_assoc(mysqli_query($con, "SELECT status FROM products WHERE id = $product_id AND supplier_id = {$supplier['id']}"))['status'];
            $new_status = $current_status === 'active' ? 'inactive' : 'active';
            $query = "UPDATE products SET status = '$new_status' WHERE id = $product_id AND supplier_id = {$supplier['id']}";
            if (mysqli_query($con, $query)) {
                log_activity('toggle_product_status', "Changed product ID $product_id status to $new_status");
                $success = "Product status updated successfully.";
            } else {
                $error = "Error updating product status: " . mysqli_error($con);
            }
            break;
    }
}

// Get supplier's products
$products = mysqli_query($con, "
    SELECT * FROM products 
    WHERE supplier_id = {$supplier['id']}
    ORDER BY created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Products - Supplier Panel</title>
    <!-- Include the same styles as supplier.php -->
</head>
<body>
    <!-- Similar structure to admin_products.php but with supplier-specific functionality -->
</body>
</html>
<?php
// Close database connection
if (isset($con)) {
    mysqli_close($con);
}