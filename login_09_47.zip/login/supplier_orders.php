<?php
// supplier_orders.php
require_once 'auth_check.php';
require_role('supplier');

$con = mysqli_connect("localhost", "root", "", "tribal_arts_db") or die("Couldn't connect");

// Get supplier information
$user_id = $_SESSION['user_id'];
$supplier_query = mysqli_query($con, "SELECT * FROM suppliers WHERE user_id = $user_id");
$supplier = mysqli_fetch_assoc($supplier_query);

// Get orders for supplier's products
$orders = mysqli_query($con, "
    SELECT o.*, u.name as customer_name, p.name as product_name, oi.quantity
    FROM orders o 
    JOIN order_items oi ON o.id = oi.order_id 
    JOIN products p ON oi.product_id = p.id 
    JOIN users u ON o.user_id = u.id 
    WHERE p.supplier_id = {$supplier['id']}
    ORDER BY o.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - Supplier Panel</title>
    <!-- Include the same styles as supplier.php -->
</head>
<body>
    <!-- Display orders related to the supplier's products -->
</body>
</html>
<?php
// Close database connection
if (isset($con)) {
    mysqli_close($con);
}