<?php
// supplier_profile.php
require_once 'auth_check.php';
require_role('supplier');

$con = mysqli_connect("localhost", "root", "", "tribal_arts_db") or die("Couldn't connect");

// Get supplier information
$user_id = $_SESSION['user_id'];
$supplier_query = mysqli_query($con, "SELECT * FROM suppliers WHERE user_id = $user_id");
$supplier = mysqli_fetch_assoc($supplier_query);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $company_name = mysqli_real_escape_string($con, $_POST['company_name']);
    $contact_number = mysqli_real_escape_string($con, $_POST['contact_number']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $business_registration = mysqli_real_escape_string($con, $_POST['business_registration']);
    $tax_id = mysqli_real_escape_string($con, $_POST['tax_id']);
    
    $query = "UPDATE suppliers SET 
              company_name = '$company_name', 
              contact_number = '$contact_number', 
              address = '$address', 
              business_registration = '$business_registration', 
              tax_id = '$tax_id' 
              WHERE user_id = $user_id";
    
    if (mysqli_query($con, $query)) {
        log_activity('update_supplier_profile', "Updated supplier profile");
        $success = "Profile updated successfully!";
        // Refresh supplier data
        $supplier_query = mysqli_query($con, "SELECT * FROM suppliers WHERE user_id = $user_id");
        $supplier = mysqli_fetch_assoc($supplier_query);
    } else {
        $error = "Error updating profile: " . mysqli_error($con);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Supplier Panel</title>
    <!-- Include the same styles as supplier.php -->
</head>
<body>
    <!-- Form to edit supplier profile information -->
</body>
</html>
<?php
// Close database connection
if (isset($con)) {
    mysqli_close($con);
}